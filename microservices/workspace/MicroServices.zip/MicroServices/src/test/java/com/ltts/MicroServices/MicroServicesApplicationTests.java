package com.ltts.MicroServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
